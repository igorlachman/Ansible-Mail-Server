postfixadmin
============

PostfixAdmin - web based administration interface for Postfix mail servers


Technically this project is still hosted in SVN/SourceForge. However, we welcome git pull requests and will merge them into subversion as necessary. If this repository (on github) becomes well used, we'll probably migrate.

(DG. 2014/05/07)


Useful Links
------------
 - [Probably all you need to read (pdf)](http://blog.cboltz.de/uploads/postfixadmin-30-english.pdf) 
 - http://postfixadmin.sf.net - the current homepage for the project
 - [What is it? (txt)](/DOCUMENTS/POSTFIXADMIN.txt)
 - [Installation instructions](/INSTALL.TXT)
 - [Wiki](http://sourceforge.net/apps/mediawiki/postfixadmin)
 - [Mailing list](https://sourceforge.net/p/postfixadmin/discussion/676076)
 - [IRC channel](irc://irc.freenode.net/postfixadmin) (#postfixadmin on irc.freenode.net).
 
  
